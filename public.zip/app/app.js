/**
 * Created by Afro on 3/20/2017.
 */
(function() {
    'use strict';

    angular.module('thai', ['timer', 'ngFileUpload', 'ngAnimate', 'ngMaterial', 'md.data.table', 'angular-loading-bar', 'ngRoute', 'ngMdIcons', 'ngCurrencyName', 'md-steppers', 'ngMeta']);

})();