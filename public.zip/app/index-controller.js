(function() {
    'use strict';

    angular
        .module('thai')
        .controller('indexCtrl', indexCtrl);

    function indexCtrl($scope, $location, $rootScope, deleteModal) {
        const ctrl = this;


        $scope.showNav = $rootScope.showNav;
        $scope.cart = $rootScope.cart;
        $scope.loggedIn = $rootScope.loggedIn;
        $scope.username = $rootScope.user.username;
        $scope.inMobile = $rootScope.inMobile.matches;
        $scope.shopRedeem = $rootScope.shopRedeem;
        $scope.search = $rootScope.searching;
        const mql = $rootScope.inMobile;
        $scope.hasDeleted = $rootScope.hasDeleted;
        $scope.loaded = false;


        let group = [
            "$root.showNav",
            "$root.loggedIn",
            "$root.user.username",
            "$root.shopRedeem",
            "$root.searching"
        ];

        $scope.$watchGroup(group, function(newValue, oldValue, scope) {
            [$scope.showNav,
                $scope.loggedIn,
                $scope.username,
                $scope.shopRedeem,
                $scope.search
            ] = newValue;
            if ($scope.loggedIn) {
                $scope.loaded = true;
            }
        }, true);

        $rootScope.$watch('cart', function(newValue, oldValue, scope) {
            $scope.itemsInCart = newValue;
        }, true);

        $rootScope.$watch('hasDeleted', function(newValue, oldValue, scope) {
            $scope.hasDeleted = newValue;
        }, true);

        $scope.location = function(url) {
            if (url === '/redeem-shop') {
                $location.url(`${url}`)
            } else {
                $location.url(`/category${url}`)
            }
        };

        $scope.scrollLeft = () => {
            let menuBar = document.querySelector('.mob-menu');
            let leftScroller = document.querySelector('.menu-scroller.left-side'),
                width = menuBar.scrollWidth;
            if (width > menuBar.scrollLeft) {
                if (leftScroller.classList.contains('disabled')) {
                    leftScroller.classList.remove('disabled')
                    leftScroller.classList.add('z-depth-2')
                }
                menuBar.scrollLeft -= 20;
            } else {
                leftScroller.classList.add('disabled')
                leftScroller.classList.remove('z-depth-2');
            }
        }

        $scope.scrollRight = () => {
            let menuBar = document.querySelector('.mob-menu');
            let rightScroller = document.querySelector('.menu-scroller.right-side'),
                width = menuBar.scrollWidth;
            if (menuBar.scrollLeft < width) {
                if (rightScroller.classList.contains('disabled')) {
                    rightScroller.classList.remove('disabled')
                    leftScroller.classList.add('z-depth-2');
                }
                menuBar.scrollLeft += 20;
            } else {
                rightScroller.classList.add('disabled')
                leftScroller.classList.remove('z-depth-2');
            }
        }

        function initComponents() {
            $('.tooltipped').tooltip()

            $(".dropdown-button").dropdown({
                inDuration: 300,
                outDuration: 225,
            });
        }

        $scope.checkout = function() {
            $location.url('/checkout')
        };

        $scope.removeFromCart = function(index, list) {
            $('.cart-button').sideNav('hide');
            deleteModal.open(index, list)
        };


        $scope.logout = function() {
            $rootScope.loggedIn = false;
            $rootScope.user = {};
            $rootScope.cart = [];
            Materialize.toast("You've successfully logged out", 1000)
        };


        ctrl.searching = function() {
            if (!$scope.search) {
                setTimeout(function() {
                    $('#search').focus()
                }, 200)
            }
            $rootScope.searching = !$rootScope.searching
            setTimeout(() => initComponents(), 200);
        };


        $scope.addToScreen = function() {
            let homeModal = $("#homescreen-modal");
            homeModal.css("opacity", 0);
            homeModal.modal('open');
            const backdrop = document.querySelector('.modal-overlay');
            backdrop.style.background = "#26848c";
            backdrop.style.opacity = 0.8;
            homeModal.css("opacity", 1);
        };

        function showMobile(e) {
            $scope.inMobile = e.matches;
        }

        mql.addListener(showMobile);

        $(".dropdown-button").dropdown({
            inDuration: 300,
            outDuration: 225,
        });
    }
})();