/**
 * Created by Afro on 6/19/2017.
 */

'use strict';

angular.module('thai')
    .component('userRewards', {
       templateUrl: 'app/profile-page/rewards/rewards.html',
        controller: rewardCtrl
    });

const rewardCtrl = () => {
    const ctrl = this;
};